#define colours
BLACK = (0, 0, 0)
WHITE = (225, 225, 225)
RED = (225, 0, 0)
GREEN = (0, 225, 0)
BLUE = (0, 0, 225)
DARK_GREY = (62, 63, 63)
GREY = (90,90,90)
LIGHT_GREY = (130,130,130)

#defining odd and even:
ODD = [1,3,5,7]
EVEN = [2,4,6,8]
#game options
TITLE = "Chess Game"
WIDTH = 512
HEIGHT = 512
FPS = 30

TILESIZE = 64
GRIDWIDTH = WIDTH / TILESIZE
GRIDHEIGHT = HEIGHT / TILESIZE


COLS = 8
ROWS = 8

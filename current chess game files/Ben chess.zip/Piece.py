import os
from settings import *

class Piece:

    def __init__(self, name, colour, value, texture=None, texture_rect=None):
        self.name = name
        self.colour = colour
        value_sign = 1 if colour == WHITE else -1
        self.value = value * value_sign
        self.moves = []
        self.moved = False
        self.moved_twice = False
        self.texture = texture
        self.set_texture()
        self.texture_rect = texture_rect

    def set_texture(self, size=80):
        if self.colour == WHITE:
            Piece_Colour = 'white'
        else:
            Piece_Colour = 'black'
        self.texture = os.path.join(
            f'assets/images/imgs-{size}px/{Piece_Colour}_{self.name}.png')

    def add_moves(self, move):
        self.moves.append(move)

    def clear_moves(self):
        self.moves = []

class Pawn(Piece):

    def __init__(self, colour):
        self.dir = -1 if colour == WHITE else 1
        super().__init__('Pawn', colour, 1.0)


class Knight(Piece):

    def __init__(self, colour):
        self.dir = -1 if colour == WHITE else 1
        super().__init__('Knight', colour, 3.0)

class Bishop(Piece):

    def __init__(self, colour):
        self.dir = -1 if colour == WHITE else 1
        super().__init__('Bishop', colour, 3.001)

class Rook(Piece):

    def __init__(self, colour):
        self.dir = -1 if colour == WHITE else 1
        super().__init__('Rook', colour, 6.0)

class Queen(Piece):

    def __init__(self, colour):
        self.dir = -1 if colour == WHITE else 1
        super().__init__('Queen', colour, 9.0)

class King(Piece):

    def __init__(self, colour):
        self.left_rook = None
        self.right_rook = None
        self.dir = -1 if colour == WHITE else 1
        super().__init__('King', colour, 1000.0)















        

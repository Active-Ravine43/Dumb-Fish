import pygame as pg
from settings import *
from Board_Class import *
from Piece_Grabber import *
from Move import *

class Game:
    
    def __init__(self):
        #initialise game window, etc
        pg.init()
        self.screen = pg.display.set_mode((WIDTH, HEIGHT))
        pg.display.set_caption(TITLE)
        self.clock = pg.time.Clock()
        self.next_player = WHITE
        self.running = True
        self.board = Board()
        self.Piece_Grabber = Piece_Grabber()
        grabber = self.Piece_Grabber
        
    def new(self):
        #start a new game
        self.run()

    def run(self):
        #game loop
        screen = self.screen
        self.playing = True
        while self.playing:
            self.clock.tick(FPS)
            self.events()
            self.update()
            self.draw()
        

    def update(self):
        #game loop - update
        pass

    def events(self):
        #game loop - events
        for event in pg.event.get():
            #event: mouse click
            if event.type == pg.MOUSEBUTTONDOWN:
                self.Piece_Grabber.update_mouse(event.pos)

                clicked_row = self.Piece_Grabber.MouseY // TILESIZE
                clicked_col = self.Piece_Grabber.MouseX // TILESIZE
                #does clicked square have a piece
                if self.board.squares[clicked_row][clicked_col].has_piece():
                    piece = self.board.squares[clicked_row][clicked_col].piece
                    #check valid player turn
                    if piece.colour == g.next_player:
                        self.board.calculate_moves(piece, clicked_row, clicked_col, bool=True)
                        self.Piece_Grabber.save_initial_pos(event.pos)
                        self.Piece_Grabber.Grab_Piece(piece)
                        self.show_possible_moves(self.screen)
            elif event.type == pg.MOUSEMOTION:
                if  self.Piece_Grabber.Holding:
                    self.Piece_Grabber.update_mouse(event.pos)
                    self.Piece_Grabber.update_grabber(self.screen)

            elif event.type == pg.MOUSEBUTTONUP:

                if self.Piece_Grabber.Holding:
                    self.Piece_Grabber.update_mouse(event.pos)

                    released_row = self.Piece_Grabber.MouseY // TILESIZE
                    released_col = self.Piece_Grabber.MouseX // TILESIZE

                    initial = Square(self.Piece_Grabber.initial_row, self.Piece_Grabber.initial_col)
                    final = Square(released_row, released_col)
                    move = Move(initial, final)

                    if self.board.valid_move(self.Piece_Grabber.piece, move):
                        self.board.move(self.Piece_Grabber.piece, move)

                        self.player_turn()


                self.Piece_Grabber.UnGrab_Piece()


            
            if event.type == pg.QUIT:
                if self.playing:
                    self.playing = False
                self.running = False
    #displays everything in a game
    def draw(self):
        #game loop - draw
        self.screen.fill(BLACK)
        self.draw_grid()
        if self.Piece_Grabber.Holding:
            self.show_possible_moves(self.screen)
        self.show_pieces(self.screen)
        #after 'drawing' everything, flip the display
        pg.display.flip()
    # displays the board
    def draw_grid(self):
        for i in range (0,8):
            for j in range (0,8):
                if (i+j) % 2 == 0:
                    colour = WHITE
                else:
                    colour = DARK_GREY
                rect = (i * TILESIZE, j * TILESIZE, TILESIZE, TILESIZE)
                pg.draw.rect(self.screen, colour, rect)


    def show_pieces(self, surface):
        for row in range(ROWS):
            for col in range(COLS):
                # piece ?
                if self.board.squares[row][col].has_piece():
                    piece = self.board.squares[row][col].piece
                    #draw any piece that is held where mouse is
                    if self.Piece_Grabber.Holding:
                        self.Piece_Grabber.update_grabber(self.screen)
                    #draw all stationary pieces
                    if piece is not self.Piece_Grabber.piece:
                        piece.set_texture(size=80)
                        img = pg.image.load(piece.texture)
                        img_center = col * TILESIZE + TILESIZE //2, row * TILESIZE + TILESIZE //2
                        piece.texture_rect = img.get_rect(center=img_center)
                        surface.blit(img, piece.texture_rect)

    def show_possible_moves(self, surface):
        if self.Piece_Grabber.Holding:
            piece = self.Piece_Grabber.piece

            for move in piece.moves:

                if (move.final.row + move.final.col) % 2 == 0:
                    colour = LIGHT_GREY
                else:
                    colour = GREY
                rect = (move.final.col * TILESIZE, move.final.row * TILESIZE, TILESIZE, TILESIZE)


                pg.draw.rect(self.screen, colour, rect)

    def show_last_move(self):
        if self.board.last_move:
            pass

    def player_turn(self):
        if self.next_player == WHITE:
            self.next_player = BLACK
        else:
            self.next_player = WHITE


    def ShowMenuScreen(self):
        # game start screen
        pass
    def ShowGameOverScreen(self):
        # end of a game screen
        pass
    

g = Game()
g.ShowMenuScreen()
while g.running :
    g.new()
    g.ShowGameOverScreen()

pg.quit()
    


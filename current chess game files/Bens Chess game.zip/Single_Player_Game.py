from Board_Class import *
from Chess_Ai import Chess_Bot
from Move import *
from Piece_Grabber import *
import random


class SinglePlayerGame:

    def __init__(self, screen, clock, running, playing):
        self.screen = screen
        pg.font.init()
        self.clock = clock
        self.player = WHITE
        self.running = running
        self.playing = playing
        self.board = Board()
        self.Piece_Grabber = Piece_Grabber()
        self.previous_moves = []
        self.Ai_Player = Chess_Bot(self.get_random_colour(), self.board)

    def new(self):
        # start a new game
        self.run()

    def run(self):
        # game loop
        while self.playing:
            # self.clock.tick(FPS)
            self.events()
            self.update()
            self.draw()

    def update(self):
        # game loop - update
        pass

    def events(self):
        if self.player == self.Ai_Player.colour:
            ai_move = self.Ai_Player.make_move()
            self.add_move_to_stack(ai_move.moved_piece, ai_move)
            self.player_turn()
            # checks for checkmate
            if not self.board.has_legal_moves(self.player) and self.board.in_check(self.player,
                                                                                   copy.deepcopy(self.board)):
                if self.playing:
                    self.playing = False
                self.running = False
            # checks for stalemate
            elif not self.board.has_legal_moves(self.player):
                if self.playing:
                    self.playing = False
                self.running = False
        else:
            for event in pg.event.get():
                # event: mouse click
                if event.type == pg.MOUSEBUTTONDOWN:
                    self.Piece_Grabber.update_mouse(event.pos)

                    clicked_row = self.Piece_Grabber.MouseY // TILESIZE
                    clicked_col = self.Piece_Grabber.MouseX // TILESIZE
                    # does clicked square have a piece
                    if self.board.squares[clicked_row][clicked_col].has_piece():
                        piece = self.board.squares[clicked_row][clicked_col].piece
                        # check valid player turn
                        if piece.colour == self.player:
                            self.board.calculate_moves(piece, clicked_row, clicked_col, bool=True)
                            self.Piece_Grabber.save_initial_pos(event.pos)
                            self.Piece_Grabber.Grab_Piece(piece)
                            self.show_possible_moves(self.screen)
                elif event.type == pg.MOUSEMOTION:
                    if self.Piece_Grabber.Holding:
                        self.Piece_Grabber.update_mouse(event.pos)
                        self.Piece_Grabber.update_grabber(self.screen)

                elif event.type == pg.MOUSEBUTTONUP:

                    if self.Piece_Grabber.Holding:
                        self.Piece_Grabber.update_mouse(event.pos)

                        released_row = self.Piece_Grabber.MouseY // TILESIZE
                        released_col = self.Piece_Grabber.MouseX // TILESIZE

                        initial = Square(self.Piece_Grabber.initial_row, self.Piece_Grabber.initial_col)
                        final = Square(released_row, released_col)
                        move = Move(initial, final, self.Piece_Grabber.piece)

                        if self.board.valid_move(self.Piece_Grabber.piece, move):
                            self.add_move_to_stack(self.Piece_Grabber.piece, move)
                            self.board.move(self.Piece_Grabber.piece, move)
                            # self.add_move_to_stack(self.Piece_Grabber.piece, move)

                            self.player_turn()

                            # checks for checkmate

                            if not self.board.has_legal_moves(self.player) and self.board.in_check(self.player,
                                                                                                   copy.deepcopy(self.board)):

                                print('checkmate')
                                if self.playing:
                                    self.playing = False
                                self.running = False

                            # checks for stalemate

                            elif not self.board.has_legal_moves(self.player):
                                print('stalemate')
                                if self.playing:
                                    self.playing = False
                                self.running = False

                    self.Piece_Grabber.UnGrab_Piece()

                elif event.type == pg.QUIT:
                    if self.playing:
                        self.playing = False
                    self.running = False

        # displays everything in a game

    def draw(self):
        # game loop - draw
        self.screen.fill(BLACK)
        self.draw_grid()
        if self.Piece_Grabber.Holding:
            self.show_possible_moves(self.screen)
        self.show_pieces(self.screen)
        if self.previous_moves:
            self.show_previous_move()
        # after 'drawing' everything, flip the display
        pg.display.flip()
        # displays the board

    def draw_grid(self):
        for i in range(0, 8):
            for j in range(0, 8):
                if (i + j) % 2 == 0:
                    colour = WHITE
                else:
                    colour = DARK_GREY
                rect = (i * TILESIZE, j * TILESIZE, TILESIZE, TILESIZE)
                pg.draw.rect(self.screen, colour, rect)

    def show_pieces(self, surface):
        for row in range(ROWS):
            for col in range(COLS):
                # piece ?
                if self.board.squares[row][col].has_piece():
                    piece = self.board.squares[row][col].piece
                    # draw any piece that is held where mouse is
                    if self.Piece_Grabber.Holding:
                        self.Piece_Grabber.update_grabber(self.screen)
                    # draw all stationary pieces
                    if piece is not self.Piece_Grabber.piece:
                        piece.set_texture(size=80)
                        img = pg.image.load(piece.texture)
                        img_center = col * TILESIZE + TILESIZE // 2, row * TILESIZE + TILESIZE // 2
                        piece.texture_rect = img.get_rect(center=img_center)
                        surface.blit(img, piece.texture_rect)

    def show_possible_moves(self, surface):
        if self.Piece_Grabber.Holding:
            piece = self.Piece_Grabber.piece

            for move in piece.moves:

                if (move.final.row + move.final.col) % 2 == 0:
                    colour = LIGHT_GREY
                else:
                    colour = GREY
                rect = (move.final.col * TILESIZE, move.final.row * TILESIZE, TILESIZE, TILESIZE)

                pg.draw.rect(self.screen, colour, rect)

    def show_previous_move(self):
        if len(self.previous_moves) < 8:
            for i in range(0, len(self.previous_moves)):
                display_move = self.previous_moves[-(1 + i)].move_in_chess_notation
                move_colour = self.previous_moves[-(1 + i)].colour
                self.text_to_screen(display_move, 8 * TILESIZE, i * TILESIZE, colour=move_colour)

        else:
            for i in range(0, 8):
                display_move = self.previous_moves[-(1 + i)].move_in_chess_notation
                move_colour = self.previous_moves[-(1 + i)].colour
                self.text_to_screen(display_move, 8 * TILESIZE, i * TILESIZE, colour=move_colour)

    def text_to_screen(self, text, x, y, size=25, colour=RED, font_type='Lucida Console'):

        text = str(text)
        font = pg.font.SysFont(font_type, size)
        text = font.render(text, True, colour)
        self.screen.blit(text, (x, y))

    def player_turn(self):
        if self.player == WHITE:
            self.player = BLACK
        else:
            self.player = WHITE

    def add_move_to_stack(self, piece, move):
        initial = move.initial
        final = move.final
        move.move_in_chess_notation = self.convert_move_into_chess_notation(piece, initial, final)
        if piece.colour == BLACK:
            move.colour = GREY
        else:
            move.colour = piece.colour

        self.previous_moves.append(move)

    def convert_move_into_chess_notation(self, piece, initial, final):

        chess_notation = ''
        initial_position = initial.col
        final_position_col = final.col
        final_position_row = final.row

        if isinstance(piece, Pawn):
            if self.board.squares[final.row][final.col].has_enemy_piece(piece.colour):
                chess_notation = cols_as_letters[initial_position] + 'x' + cols_as_letters[final_position_col] + \
                                 rows_as_characters[final_position_row]
            else:
                chess_notation = cols_as_letters[final_position_col] + rows_as_characters[final_position_row]

        if isinstance(piece, Bishop):
            if self.board.squares[final.row][final.col].has_enemy_piece(piece.colour):
                chess_notation = bishop_character + 'x' + cols_as_letters[final_position_col] + rows_as_characters[
                    final_position_row]
            else:
                chess_notation = bishop_character + cols_as_letters[final_position_col] + rows_as_characters[
                    final_position_row]

        if isinstance(piece, Knight):
            if self.board.squares[final.row][final.col].has_enemy_piece(piece.colour):
                chess_notation = knight_character + 'x' + cols_as_letters[final_position_col] + rows_as_characters[
                    final_position_row]
            else:
                chess_notation = knight_character + cols_as_letters[final_position_col] + rows_as_characters[
                    final_position_row]

        if isinstance(piece, Rook):
            if self.board.squares[final.row][final.col].has_enemy_piece(piece.colour):
                chess_notation = rook_character + 'x' + cols_as_letters[final_position_col] + rows_as_characters[
                    final_position_row]
            else:
                chess_notation = rook_character + cols_as_letters[final_position_col] + rows_as_characters[
                    final_position_row]

        if isinstance(piece, Queen):
            if self.board.squares[final.row][final.col].has_enemy_piece(piece.colour):
                chess_notation = queen_character + 'x' + cols_as_letters[final_position_col] + rows_as_characters[
                    final_position_row]
            else:
                chess_notation = queen_character + cols_as_letters[final_position_col] + rows_as_characters[
                    final_position_row]

        if isinstance(piece, King):
            if self.board.squares[final.row][final.col].has_enemy_piece(piece.colour):
                chess_notation = king_character + 'x' + cols_as_letters[final_position_col] + rows_as_characters[
                    final_position_row]
            else:
                chess_notation = king_character + cols_as_letters[final_position_col] + rows_as_characters[
                    final_position_row]

        return chess_notation

    def ShowMenuScreen(self):
        # game start screen
        pass

    def ShowGameOverScreen(self):
        # end of a game screen
        pass

    def get_random_colour(self):
        number = random.randint(1, 2)
        if number == 1:
            return WHITE
        else:
            return BLACK

#single_player = SinglePlayerGame(pg.display.set_mode((width, height)), pg.time.Clock(), True, True)
#single_player.new()
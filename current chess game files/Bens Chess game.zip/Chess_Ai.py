import copy
import math
from collections import deque

from Board_Class import *

#if opponent move leads to check, attacking high value piece, atacking/capturing unguarded piece
class Chess_Bot:

    def __init__(self, colour, board):
        self.colour = colour
        self.board = board

    def make_move(self, board, difficulty=3):

        move = self.find_best_moves(copy.deepcopy(board), self.colour, depth=difficulty)
        #move.board = copy.deepcopy(board)
        print(move)
        if move is not None:
            initial_square = board.squares[move.initial.row][move.initial.col]
            piece = initial_square.piece
            move.board = copy.deepcopy(board)

            if piece is not None:
                board.move(piece, move)

        return move

    def find_best_moves(self, board, colour, depth=3, alpha=-math.inf, beta=math.inf):
        if depth <= 0:
            evaluation = self.eval_board(board, colour)
            dummy_move = self.create_dummy_move(evaluation)
            return dummy_move

        best_move = None
        #max_value = -math.inf
        all_moves = self.generate_all_moves(board, colour)

        if not all_moves:
            return None


        if all_moves and depth != 0:
            for m in all_moves:
                piece = m.moved_piece
                board.move(piece, m, testing=True)
                self.assign_move_value(board, m)
                opponent_move = self.find_best_moves(board, self.opposite_colour(colour), depth=depth - 1, alpha=-beta, beta=-alpha)
                print(opponent_move)
                self.undo_move(board, m, piece)
                if opponent_move is not None and hasattr(opponent_move, 'move_value'):
                    current_value = - opponent_move.move_value
                    m.move_value = m.move_value - opponent_move.move_value
                    if current_value > alpha:
                        alpha = current_value
                        best_move = m

                    if alpha >= beta:
                        print('pruned')
                        break

            return best_move

    def create_dummy_move(self, move_value):
        dummy_move = Dummy_Move(move_value)
        return dummy_move

    def generate_all_moves(self, board, colour):
        best = -math.inf
        #worst = math.inf
        moves = []
        for row in range(ROWS):
            for col in range(COLS):
                if board.squares[row][col].has_team_piece(colour):
                    piece = board.squares[row][col].piece
                    #if piece.moves:
                    piece_move = self.generate_piece_moves(board, piece, row, col, best)
                    if piece_move is not None:
                        #best = piece_move.estimate_val
                        moves.append(piece_move)
        if moves:
            moves = self.sort_moves(moves, board, colour)
        return moves

    def generate_piece_moves(self, board, piece, row, col, best):
        best_move = None
        board.calculate_moves(piece, row, col)
        for m in piece.moves:
            if board.valid_move(piece, m):
                self.estimate_move_value(board, m, piece)
                if m.estimate_val >= best:
                    best = m.estimate_val
                    best_move = m
        return best_move


    def assign_move_value(self, board, move):
        #capture_value = 0
        #if move.captured_piece is not None:
            #capture_value = self.what_piece(move.captured_piece)
        evaluation = self.eval_board(board, move.colour) #+ capture_value
        print(evaluation)
        move.move_value = evaluation

    def estimate_move_value(self, board, move, piece):
        capture_value = 0
        if move.captured_piece is not None:
            capture_value = self.what_piece(move.captured_piece)
        positional_evaluation = piece.piece_eval_table[move.final.row][move.final.col]
        material_evaluation_self = self.evaluate_piece_value(board, move.colour)
        material_evaluation_opponent =  - self.evaluate_piece_value(board, self.opposite_colour(piece.colour))
        move.estimate_val = positional_evaluation + material_evaluation_self + material_evaluation_opponent + capture_value

    def eval_check(self, board, move):
        square = board.squares[move.final.row][move.final.col]
        if not square.has_piece():
            return False
        else:
            if isinstance(square.piece, King):
                return True
            else:
                return False

    def eval_board(self, board, colour):
        value = 0
        for row in range(ROWS):
            for col in range(COLS):
                square = board.squares[row][col]
                if square.has_team_piece(colour):
                    #print('found team')
                    value += self.what_piece(square.piece)
                    value += square.piece.piece_eval_table[row][col]
                elif square.has_enemy_piece(colour):
                    #print('found enemy')
                    value = value - self.what_piece(square.piece)
        is_move_check = self.evaluate_if_gives_check(board, self.opposite_colour(colour))
        value += is_move_check
        print(value)
        return value

    def evaluate_if_capture(self, board, move, colour):
        value = 0
        if board.squares[move.final.row][move.final.col].has_enemy_piece(colour):
            value = self.what_piece(board.squares[move.final.row][move.final.col].piece)
        return value

    def evaluate_material(self, board, colour):

        board_value = self.evaluate_piece_value(board,colour) - self.evaluate_piece_value(board,
                                                                                           self.opposite_colour(colour))
        return board_value

    def eval_move_material_val(self, board, move, colour):
        team_value = 0
        for row in range(ROWS):
            for col in range(COLS):
                if not row == move.final.row and not col == move.final.col:
                    possible_piece = board.squares[row][col]
                    if possible_piece.has_team_piece(colour):
                        print('Possible piece found and not in final square')
                        team_value += self.what_piece(possible_piece.piece)
        return team_value

    def evaluate_piece_value(self, board, colour):
        team_value = 0
        for row in range (ROWS):
            for col in range (COLS):
                possible_piece = board.squares[row][col]
                if possible_piece.has_team_piece(colour):
                    team_value += self.what_piece(possible_piece.piece)
        return team_value

    def evaluate_if_gives_check(self, board, colour):
        value = 0
        if board.in_check(self.opposite_colour(colour), board):
            value = 500
            if not board.has_legal_moves(self.opposite_colour(colour)):
                value = 10,000
        return value

    def eval_board_position(self, piece, move):
        pass
        #piece.piece_eval_table[move.final.row][move.final.col]
        #return positional_value

    def what_piece(self, piece):
        if isinstance(piece, Pawn):
            return PVALUE
        elif isinstance(piece, Knight):
            return NVALUE
        elif isinstance(piece, Bishop):
            return BVALUE
        elif isinstance(piece, Rook):
            return RVALUE
        elif isinstance(piece, Queen):
            return QVALUE
        elif isinstance(piece, King):
            return KVALUE

    def opposite_colour(self, colour):
        if colour == WHITE:
            return BLACK
        else:
            return WHITE

    def return_move_val(self, move):
        return move.move_value

    def return_move_estimate_val(self, move):
        return move.estimate_val

    def undo_move(self, board, move, piece):
        if move.captured_piece:
            board.squares[move.initial.row][move.initial.col].piece = piece

            board.squares[move.final.row][move.final.col].piece = move.captured_piece
            move.captured_piece = None
        else:
            board.squares[move.initial.row][move.initial.col].piece = piece
            board.squares[move.final.row][move.final.col].piece = None

    def sort_moves(self, moves, board, colour):
        best_moves = []
        best_value = - math.inf
        #best_capture_position = -1
        moves.sort(key=self.return_move_estimate_val, reverse=True)
        if len(moves) > 3:
            for i in range (0, 3):
                if moves[i].estimate_val >= best_value:
                    best_value = moves[i].estimate_val
                    best_moves.append(moves[i])
        else:
            best_moves = moves

        return best_moves
